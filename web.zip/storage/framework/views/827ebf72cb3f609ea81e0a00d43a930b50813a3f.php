<?php $__env->startSection('content'); ?>

    <h1>Create Page</h1>

    <form action="<?php echo e(url('presence')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label for="subject" class="form-label">Subject</label>
                    <input name="subject" type="text" class="form-control" id="subject" required>
                </div>

                <div class="mb-3">
                    <label for="date" class="form-label">Date</label>
                    <input name="date" type="text" class="form-control" id="date" required>
                </div>

                <div class="mb-3">
                    <label for="presence_screenshot" class="form-label">Screenshot</label>
                    <input name="presence_screenshot" type="file" class="form-control" id="presence_screenshot">
                </div>

                <label for="status" class="form-label">Status</label>
                <div class="input-group">
                    <select class="form-select mb-3" name="status" id="status"
                        aria-label="Example select with button addon">
                        <option value="Presence">Presence</option>
                        <option value="Sick/Excuse">Sick/Excuse</option>
                        <option value="Alpha">Alpha</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfarizi/Documents/Laravel Web Development/assignment-systems/resources/views/Presence/create.blade.php ENDPATH**/ ?>