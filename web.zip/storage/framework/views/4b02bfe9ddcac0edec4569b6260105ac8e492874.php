<?php $__env->startSection('content'); ?>

    <h1><b>My Schedule</b></h1>
    <a href="<?php echo e(url('schedule/create')); ?>" class="btn btn-primary">Add Shedule</a>
    <div class="row mt-4">
        <div class="col">
            <center>
                <h3>Monday</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Start</b></center>
                        </th>
                        <th scope="col">
                            <center><b>End</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>From</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $monday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="col">
                                <h4><span class="badge bg-danger"><?php echo e($item->start_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h4><span class="badge bg-primary"><?php echo e($item->end_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h5><b><?php echo e($item->subject); ?></b></h5>
                            </th>
                            <th scope="col">
                                <h5><center><?php echo e($item->from); ?></center></h5>
                            </th>
                            <th scope="col">
                                <?php if($item->from === 'College'): ?><a
                                        href="<?php echo e($item->classroom_link); ?>" class="btn btn-success">Classroom</a><br>
                                <?php endif; ?>
                                <a href="<?php echo e($item->meet_link); ?>" class="btn btn-primary mt-1">Meet</a>
                                <a href="<?php echo e(url('/schedule/'.$item->id.'/edit')); ?>" class="btn btn-warning mt-1">Update</a>
                                <form action="<?php echo e(url('/schedule/'.$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger mt-1" onclick="confirm('Delete this schedule ?')">Delete</a>
                                </form>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col">
            <center>
                <h3>Tuesday</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Start</b></center>
                        </th>
                        <th scope="col">
                            <center><b>End</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>From</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tuesday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="col">
                                <h4><span class="badge bg-danger"><?php echo e($item->start_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h4><span class="badge bg-primary"><?php echo e($item->end_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h5><b><?php echo e($item->subject); ?></b></h5>
                            </th>
                            <th scope="col">
                                <h5><center><?php echo e($item->from); ?></center></h5>
                            </th>
                            <th scope="col">
                                <?php if($item->from === 'College'): ?><a
                                        href="<?php echo e($item->classroom_link); ?>" class="btn btn-success">Classroom</a><br>
                                <?php endif; ?>
                                <a href="<?php echo e($item->meet_link); ?>" class="btn btn-primary mt-1">Meet</a>
                                <a href="<?php echo e(url('/schedule/'.$item->id.'/edit')); ?>" class="btn btn-warning mt-1">Update</a>
                                <form action="<?php echo e(url('/schedule/'.$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger mt-1" onclick="confirm('Delete this schedule ?')">Delete</a>
                                </form>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <center>
                <h3>Wednesday</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Start</b></center>
                        </th>
                        <th scope="col">
                            <center><b>End</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>From</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $wednesday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="col">
                                <h4><span class="badge bg-danger"><?php echo e($item->start_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h4><span class="badge bg-primary"><?php echo e($item->end_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h5><b><?php echo e($item->subject); ?></b></h5>
                            </th>
                            <th scope="col">
                                <h5><center><?php echo e($item->from); ?></center></h5>
                            </th>
                            <th scope="col">
                                <?php if($item->from === 'College'): ?><a
                                        href="<?php echo e($item->classroom_link); ?>" class="btn btn-success">Classroom</a><br>
                                <?php endif; ?>
                                <a href="<?php echo e($item->meet_link); ?>" class="btn btn-primary mt-1">Meet</a>
                                <a href="<?php echo e(url('/schedule/'.$item->id.'/edit')); ?>" class="btn btn-warning mt-1">Update</a>
                                <form action="<?php echo e(url('/schedule/'.$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger mt-1" onclick="confirm('Delete this schedule ?')">Delete</a>
                                </form>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col">
            <center>
                <h3>Thursday</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Start</b></center>
                        </th>
                        <th scope="col">
                            <center><b>End</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>From</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $thursday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="col">
                                <h4><span class="badge bg-danger"><?php echo e($item->start_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h4><span class="badge bg-primary"><?php echo e($item->end_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h5><b><?php echo e($item->subject); ?></b></h5>
                            </th>
                            <th scope="col">
                                <h5><center><?php echo e($item->from); ?></center></h5>
                            </th>
                            <th scope="col">
                                <?php if($item->from === 'College'): ?><a
                                        href="<?php echo e($item->classroom_link); ?>" class="btn btn-success">Classroom</a><br>
                                <?php endif; ?>
                                <a href="<?php echo e($item->meet_link); ?>" class="btn btn-primary mt-1">Meet</a>
                                <a href="<?php echo e(url('/schedule/'.$item->id.'/edit')); ?>" class="btn btn-warning mt-1">Update</a>
                                <form action="<?php echo e(url('/schedule/'.$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger mt-1" onclick="confirm('Delete this schedule ?')">Delete</a>
                                </form>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <center>
                <h3>Friday</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Start</b></center>
                        </th>
                        <th scope="col">
                            <center><b>End</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>From</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $friday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="col">
                                <h4><span class="badge bg-danger"><?php echo e($item->start_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h4><span class="badge bg-primary"><?php echo e($item->end_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h5><b><?php echo e($item->subject); ?></b></h5>
                            </th>
                            <th scope="col">
                                <h5><center><?php echo e($item->from); ?></center></h5>
                            </th>
                            <th scope="col">
                                <?php if($item->from === 'College'): ?><a
                                        href="<?php echo e($item->classroom_link); ?>" class="btn btn-success">Classroom</a><br>
                                <?php endif; ?>
                                <a href="<?php echo e($item->meet_link); ?>" class="btn btn-primary mt-1">Meet</a>
                                <a href="<?php echo e(url('/schedule/'.$item->id.'/edit')); ?>" class="btn btn-warning mt-1">Update</a>
                                <form action="<?php echo e(url('/schedule/'.$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger mt-1" onclick="confirm('Delete this schedule ?')">Delete</a>
                                </form>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col">
            <center>
                <h3>Saturday</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Start</b></center>
                        </th>
                        <th scope="col">
                            <center><b>End</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>From</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $saturday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="col">
                                <h4><span class="badge bg-danger"><?php echo e($item->start_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h4><span class="badge bg-primary"><?php echo e($item->end_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h5><b><?php echo e($item->subject); ?></b></h5>
                            </th>
                            <th scope="col">
                                <h5><center><?php echo e($item->from); ?></center></h5>
                            </th>
                            <th scope="col">
                                <?php if($item->from === 'College'): ?><a
                                        href="<?php echo e($item->classroom_link); ?>" class="btn btn-success">Classroom</a><br>
                                <?php endif; ?>
                                <a href="<?php echo e($item->meet_link); ?>" class="btn btn-primary mt-1">Meet</a>
                                <a href="<?php echo e(url('/schedule/'.$item->id.'/edit')); ?>" class="btn btn-warning mt-1">Update</a>
                                <form action="<?php echo e(url('/schedule/'.$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger mt-1" onclick="confirm('Delete this schedule ?')">Delete</a>
                                </form>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col">
            <center>
                <h3>Sunday</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Start</b></center>
                        </th>
                        <th scope="col">
                            <center><b>End</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>From</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sunday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="col">
                                <h4><span class="badge bg-danger"><?php echo e($item->start_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h4><span class="badge bg-primary"><?php echo e($item->end_time); ?></span></h4>
                            </th>
                            <th scope="col">
                                <h5><b><?php echo e($item->subject); ?></b></h5>
                            </th>
                            <th scope="col">
                                <h5><center><?php echo e($item->from); ?></center></h5>
                            </th>
                            <th scope="col">
                                <?php if($item->from === 'College'): ?><a
                                        href="<?php echo e($item->classroom_link); ?>" class="btn btn-success">Classroom</a><br>
                                <?php endif; ?>
                                <a href="<?php echo e($item->meet_link); ?>" class="btn btn-primary mt-1">Meet</a>
                                <a href="<?php echo e(url('/schedule/'.$item->id.'/edit')); ?>" class="btn btn-warning mt-1">Update</a>
                                <form action="<?php echo e(url('/schedule/'.$item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger mt-1" onclick="confirm('Delete this schedule ?')">Delete</a>
                                </form>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col">
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfarizi/Documents/Laravel Web Development/assignment-systems/resources/views/Schedule/index.blade.php ENDPATH**/ ?>