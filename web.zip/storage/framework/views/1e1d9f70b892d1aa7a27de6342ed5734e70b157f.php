<?php $__env->startSection('content'); ?>

    <h1>Update Page</h1>

    <form action="<?php echo e(url('/exam/'.$exam->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT">
        <div class="row">
            <div class="col-md-4">
                <div class="mb-3">
                    <label for="subject" class="form-label">Subject</label>
                    <input name="subject" type="text" class="form-control" id="subject" required value="<?php echo e($exam->subject); ?>">
                </div>
                <div class="mb-3">
                    <label for="lesson" class="form-label">Lesson</label>
                    <input name="lesson" type="text" class="form-control" id="lesson" required value="<?php echo e($exam->lesson); ?>">
                </div>
                <label for="category" class="form-label">Category</label>
                <div class="input-group">
                    <select class="form-select mb-3" name="category" id="category"
                        aria-label="Example select with button addon">
                        <option value="Quiz" <?php if($exam->category == 'Quiz'): ?>
                            selected
                        <?php endif; ?>>Quiz</option>
                        <option value="UTS" <?php if($exam->category == 'UTS'): ?>
                            selected
                        <?php endif; ?>>UTS</option>
                        <option value="UAS" <?php if($exam->category == 'UAS'): ?>
                            selected
                        <?php endif; ?>>UAS</option>
                    </select>
                </div>
            </div>
            <?php
                $datetime = $exam->datetime;
                $datetime_exploded = explode(' ', $datetime);
                $date = $datetime_exploded[0];
                $time = $datetime_exploded[1];
                $time = str_replace("(", "", $time);
                $time = str_replace(")", "", $time);
            ?>
            <div class="col-md-4">
                <div class="mb-3">
                    <label for="date" class="form-label">Date</label>
                    <input name="date" type="text" class="form-control" id="date" required value="<?php echo e($date); ?>">
                </div>
                <div class="mb-3">
                    <label for="time" class="form-label">Time</label>
                    <input name="time" type="text" class="form-control" id="time" required value="<?php echo e($time); ?>">
                </div>
                <label for="Status" class="form-label">Status</label>
            <div class="input-group">
                <select class="form-select mb-3" name="status" id="Status"
                    aria-label="Example select with button addon">
                    <option value="Not yet" <?php if($exam->status == 'Not yet'): ?>
                        selected
                    <?php endif; ?>>Not yet</option>
                    <option value="Completed" <?php if($exam->status == 'Completed'): ?>
                        selected
                    <?php endif; ?>>Completed</option>
                </select>
            </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfarizi/Documents/Laravel Web Development/assignment-systems/resources/views/Exam/update.blade.php ENDPATH**/ ?>