<?php
$date = date('F j, Y');
$time = date('g:i a');
?>


<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfarizi/Documents/Laravel Web Development/assignment-systems/resources/views/dashboard.blade.php ENDPATH**/ ?>