<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <h2 class="card-header"><b><?php echo e($assignment->subject); ?></b></h2>
                <div class="row p-2">
                    <?php if($assignment->assignment_screenshot): ?>
                        <div class="col-md-5">
                            <a href="<?php echo e('/images/Assignment/' . $assignment->assignment_screenshot); ?>"
                                target="_blank"><img
                                    src="<?php echo e('/images/Assignment/' . $assignment->assignment_screenshot); ?>" alt=""
                                    width="100%"></a>
                        </div>
                    <?php endif; ?>
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5><?php echo e($assignment->description); ?></h5>
                            <table border="0" class="mt-3">
                                <tr>
                                    <td>
                                        <h6>Assigned </h6>
                                    </td>
                                    <td>
                                        <h6> : </h6>
                                    </td>
                                    <td>
                                        <h6><?php echo e($assignment->assigned_date); ?></h6>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6>Deadline </h6>
                                    </td>
                                    <td>
                                        <h6> : </h6>
                                    </td>
                                    <td>
                                        <h6><?php echo e($assignment->deadline_date); ?></h6>
                                    </td>
                                </tr>
                            </table>
                            <a href="<?php echo e(url('/assignment/'.$assignment->id.'/edit')); ?>" class="btn btn-warning">Update</a>
                            <form action="<?php echo e(url('/assignment/'.$assignment->id)); ?>" method="POST" style="display: inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="DELETE">
                                <button type="submit" class="btn btn-danger" onclick="confirm('Delete this Data ?')">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfarizi/Documents/Laravel Web Development/assignment-systems/resources/views/Assignment/detail.blade.php ENDPATH**/ ?>