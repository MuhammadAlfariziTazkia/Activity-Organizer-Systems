<?php $__env->startSection('content'); ?>
    <h1><b>My Exam</b></h1>
    <a href="<?php echo e(url('exam/create')); ?>" class="btn btn-primary">Add Exam</a>
    <div class="row mt-4">
        <div class="col">
            <center>
                <h3>On Going</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Time</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Lesson</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Category</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $exam_undone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->datetime); ?></td>
                            <td>
                                <h5><?php echo e($item->subject); ?></h5>
                            </td>
                            <td><?php echo e($item->lesson); ?></td>
                            <td><?php echo e($item->category); ?></td>
                            <td><a href="<?php echo e(url('/exam/'.$item->id.'/edit')); ?>" class="btn btn-warning">Update</a>
                                <form action="<?php echo e(url('/exam/' . $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger" onclick="confirm('Do you want to delete this data?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col">
            <center>
                <h3>Completed</h3>
            </center>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center><b>Time</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Subject</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Lesson</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Category</b></center>
                        </th>
                        <th scope="col">
                            <center><b>Action</b></center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $exam_done; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->datetime); ?></td>
                            <td>
                                <h5><?php echo e($item->subject); ?></h5>
                            </td>
                            <td><?php echo e($item->lesson); ?></td>
                            <td><?php echo e($item->category); ?></td>
                            <td><a href="<?php echo e(url('/exam/'.$item->id.'/edit')); ?>" class="btn btn-warning">Update</a>
                                <form action="<?php echo e(url('/exam/' . $item->id)); ?>" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-danger" onclick="confirm('Do you want to delete this data?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfarizi/Documents/Laravel Web Development/assignment-systems/resources/views/Exam/index.blade.php ENDPATH**/ ?>