<?php $__env->startSection('content'); ?>
    <h1><b>My Presence</b></h1>
    <a href="<?php echo e(url('presence/create')); ?>" class="btn btn-primary">Add Presence</a>
    <table class="table table-dark table-hover mt-4">
        <thead>
            <tr>
                <th scope="col">
                    <center><b>Subject</b></center>
                </th>
                <th scope="col">
                    <center><b>Date</b></center>
                </th>
                <th scope="col">
                    <center><b>Proof</b></center>
                </th>
                <th scope="col">
                    <center><b>Status</b></center>
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="col">
                        <center><?php echo e($item->subject); ?></center>
                    </td>
                    <td scope="col">
                        <center><?php echo e($item->date); ?></center>
                    </td>
                    <td scope="col">
                        <center><a href="<?php echo e('/images/Presence/' . $item->presence_screenshot); ?>" target="_blank"
                                class="btn btn-danger">Download Proof</a></center>
                    </td>
                    <td scope="col">
                        <h5><b>
                                <center><span <?php if($item->status == 'Presence'): ?>
                                        class="badge bg-primary"
            <?php endif; ?>
            <?php if($item->status == 'Sick/Excuse'): ?>
                class="badge bg-success"
            <?php endif; ?>
            <?php if($item->status == 'Alpha'): ?>
                class="badge bg-danger"
            <?php endif; ?>
            ><?php echo e($item->status); ?></span></center></b></h5>
            </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfarizi/Documents/Laravel Web Development/assignment-systems/resources/views/Presence/index.blade.php ENDPATH**/ ?>