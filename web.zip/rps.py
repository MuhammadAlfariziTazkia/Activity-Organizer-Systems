import os

os.system('/opt/lampp/manager-linux-x64.run')
print('Success Running Program')
