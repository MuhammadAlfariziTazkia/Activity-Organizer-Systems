<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Assignment;
use File;
use Illuminate\Support\Facades\Auth;


class AssignmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        //
        $title = 'My Assignment';
        $assignment_undone = Assignment::all()->where('user', Auth::user()->email)->where('status', 'Not Finished')->sortBy('deadline');
        $assignment_done = Assignment::all()->where('user', Auth::user()->email)->where('status', 'Finished')->sortBy('deadline');
        return view('Assignment.index', [
            'assignment_undone' => $assignment_undone,
            'assignment_done' => $assignment_done,
            'title' => $title
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $title = 'Create Assignment';
        return view('Assignment.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $current_date = date('Y-m-d');
        
        $assignment_attachment = $request->file('assignment_screenshot');
        
        $assignment = new Assignment;
        $assignment->subject = $request->subject;
        $assignment->description = $request->description;
        $assignment->assignment_link = $request->assignment_link;
        $assignment->assigned_date = $current_date;
        $assignment->deadline_date = $request->deadline_date;
        $assignment->user = Auth::user()->email;
        $assignment->status = 'Not Finished';

        if($assignment_attachment){
            $original_name = $assignment_attachment->getClientOriginalName();
            $assignment_file_name = $current_date.' '.$original_name;
            $assignment->assignment_screenshot = $assignment_file_name;
            $assignment_attachment->move(public_path().'/images/Assignment', $assignment_file_name);
        }

        $assignment->save();

        return redirect ('assignment');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $title = 'Detail Assignment';
        $assignment = Assignment::find($id);
        return view('Assignment.detail', compact('assignment', 'title'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $title = 'Edit Assignment';
        $assignment = Assignment::find($id);
        return view('Assignment.update', compact('assignment', 'title'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $current_date = date('Y-m-d');
        
        $assignment_attachment = $request->file('assignment_screenshot');
        $finished_attachment = $request->file('finished_screenshot');

        $assignment = Assignment::find($id);
        if($assignment_attachment){
            File::delete(public_path().'/images/Assignment/'.$assignment->assignment_screenshot);
            $original_name = $assignment_attachment->getClientOriginalName();
            $assignment_file_name = $current_date.' '.$original_name;
            $assignment->assignment_screenshot = $assignment_file_name;
            $assignment_attachment->move(public_path().'/images/Assignment', $assignment_file_name);
        }

        if($finished_attachment){
            File::delete(public_path().'/images/Assignment/'.$assignment->finished_screenshot);
            $original_name = $finished_attachment->getClientOriginalName();
            $finished_file_name = $current_date.' '.$original_name;
            $assignment->finished_screenshot = $finished_file_name;
            $finished_attachment->move(public_path().'/images/Assignment', $finished_file_name);
        }

        $assignment->subject = $request->subject;
        $assignment->description = $request->description;
        $assignment->assignment_link = $request->assignment_link;
        $assignment->deadline_date = $request->deadline_date;
        $assignment->status = $request->status;

        $assignment->save();

        return redirect('assignment');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $assignment = Assignment::find($id);

        if($assignment->assignment_screenshot != ''){
            File::delete(public_path().'/images/Assignment/'.$assignment->assignment_screenshot);
        }

        if($assignment->finished_screenshot != ''){
            File::delete(public_path().'/images/Assignment/'.$assignment->finished_screenshot);
        }
        $assignment->delete();

        return redirect('assignment');
    }
}
